tag @s add blue.tr.vex
advancement grant @s only blue:tr/trust vex
advancement grant @a only blue:tr/display/vex
scoreboard players set @s blue.tr.mobs_killed 0
scoreboard players set #.tr.vex_completed blue.config 1
data modify storage blue:trims logs.append.trim set value {"translate":"Vex","color":"#CFC6A5"}
function blue:tr/completion/z/setup
data modify storage blue:trims vex.owner.text set from storage blue:shared player_name
data modify storage blue:trims vex.owner.color set value "#CFC6A5"
execute if score #.tr.armor_ownership blue.config matches 1 run return fail
execute if score #.tr.objective_announcements blue.config matches 1 run tellraw @a [{"text":"- ","color":"dark_gray"},{"selector":"@s","color":"#CFC6A5"}," ",{"translate":"blue.tr.announce_completion","fallback":"has completed the objective for","color":"gray"}," ",{"translate":"Vex","color":"#CFC6A5"}]
function blue:tr/delayed/cmd/msg/vex
loot give @s loot blue:tr/vex
scoreboard players reset #.vex_stored blue.misc
execute store result score #.temp blue.misc run clear @s vex_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.vex_stored blue.misc 4
playsound entity.vex.death player @a ~ ~ ~ 2 1
playsound entity.vex.death player @a ~ ~ ~ 2 0.5
playsound entity.vex.charge player @a ~ ~ ~ 2 0.5
playsound entity.allay.ambient_with_item player @a[x=0] ~ ~ ~ 3 2
particle white_smoke ~ ~1 ~ 0.1 0.1 0.1 0.25 340
effect give @s strength 2 1 true
effect give @s speed 1 1 true