effect give @s glowing 6 0 true
effect give @s slowness 5 0 true
advancement revoke @s only blue:tr/tame_kill req
particle item{item:cactus} ~ ~1 ~ 0.4 0.6 0.4 0.1 32
playsound entity.zombie_villager.cure player @s ~ ~ ~ 2 2
execute if entity @a[tag=blue.tr.wild,limit=1] run return run damage @s 4 blue:tr/poke by @a[tag=blue.tr.wild,limit=1]
execute unless entity @a[tag=blue.tr.wild,limit=1] run damage @s 4 blue:tr/poke