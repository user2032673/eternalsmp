attribute @s[tag=!blue.tr.trim.sentry] generic.armor_toughness modifier add b163102f-0-4-0-1 "blue:tr.set" 3.5 add_value
attribute @s[tag=blue.tr.trim.sentry] generic.armor_toughness modifier add b163102f-0-4-0-1 "blue:tr.set" 5.6 add_value
advancement grant @s[advancements={blue:tr/display/diamond=false}] only blue:tr/display/diamond
tag @s add blue.tr.mats.set