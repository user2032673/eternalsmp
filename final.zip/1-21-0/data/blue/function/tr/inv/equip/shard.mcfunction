execute if score #.tr.silence_toggle blue.config matches 2 run return run tellraw @s {"translate":"blue.tr.empowerment","fallback":"- %s empowerment is disabled on this server.","color":"gray","with":[{"translate":"Silence","extra":["'s"],"color":"#3842Cf"}]}
execute at @s[advancements={blue:tr/display/shard=false},tag=!blue.tr.ignore_first] run function blue:tr/inv/equip/first/shard
execute if entity @s[advancements={blue:tr/tags={tutorial_resource_pack=false}}] run function blue:tr/inv/equip/first/resource_tutorial
advancement grant @s only blue:tr/display/shard
tag @s add blue.tr.mats.shard
tag @s add blue.tr.mats.set