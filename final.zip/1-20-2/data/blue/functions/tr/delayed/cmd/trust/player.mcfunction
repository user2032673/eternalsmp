execute store result storage blue:trims temp.id int 1 run scoreboard players operation #.temp blue.misc = @s blue.id
execute store result storage blue:trims temp.click int 1 run scoreboard players add #.temp blue.misc 1000
$function blue:tr/delayed/cmd/trust/$(function) with storage blue:trims temp